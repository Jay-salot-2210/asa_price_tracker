ALGOD_INDEXER_URL = "https://algoindexer.algoexplorerapi.io"
ASA_ID = 31566704  
PRICE_THRESHOLD = 1.0  
